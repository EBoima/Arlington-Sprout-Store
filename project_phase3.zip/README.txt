
This repository contains a simple PHP application that allows users to add and view items in a database. The application includes the following files:

- `Database.php`: Contains a PHP class that establishes a connection to the database.

- `addItem.php`: Contains a PHP script that creates a new item in the database when a user submits the form.

- `deleteItem.php`: Contains a PHP script that deletes an item from the database when a user clicks the delete button.

- `ITEM.php`: Contains a PHP class that represents the table ITEM in the Arlington Sprouts database.

- `open.php`: This file contains a PHP script that retrieves all items from the database and displays them in an HTML table.

- `Service.php`: This file contains a PHP class that provides methods for interacting with the database, such as fetching all items and adding a new item to the database.

- `iId` (int): The ID of the item.
- `Iname` (varchar): The name of the item.
- `sPrice` (float): The price of the item.

Application can be ran by opening `open.php` in a web browser. This will display a table of all items in the database, and you can add new items by filling out the form in `addItem.php`.